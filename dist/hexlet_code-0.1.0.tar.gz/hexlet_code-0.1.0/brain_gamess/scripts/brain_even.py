#!/usr/bin/env python3

from brain_gamess.games import even_game
from brain_gamess.logic import games_result


def main():
    games_result(even_game)


if __name__ == '__main__':
    main()
