# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_gamess', 'brain_gamess.games', 'brain_gamess.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_gamess.scripts.brain_calc:main',
                     'brain-even = brain_gamess.scripts.brain_even:main',
                     'brain-games = brain_gamess.scripts.brain_games:main',
                     'brain-gcd = brain_gamess.scripts.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Maksim75ru/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Maksim75ru/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/4069d408ee904b1ee322/maintainability)](https://codeclimate.com/github/Maksim75ru/python-project-49/maintainability)\n\n### How to install:\n`python3 -m pip install --user git+https://github.com/Maksim75ru/python-project-49.git`\n\n### Game 1: Is That Even?\n\n[![asciicast](https://asciinema.org/a/wmVqdtBxpsfMSPA5IcabkBLfT.svg)](https://asciinema.org/a/wmVqdtBxpsfMSPA5IcabkBLfT)\n\n### Game 2: Calculator\n\n[![asciicast](https://asciinema.org/a/lKLJLAB9re1lfDF982tteRE51.svg)](https://asciinema.org/a/lKLJLAB9re1lfDF982tteRE51)\n',
    'author': 'Maksim Lesnikov',
    'author_email': 'maximborzya75@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
