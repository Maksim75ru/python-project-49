### Hexlet tests and linter status:
[![Actions Status](https://github.com/Maksim75ru/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Maksim75ru/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/4069d408ee904b1ee322/maintainability)](https://codeclimate.com/github/Maksim75ru/python-project-49/maintainability)

### How to install:
`python3 -m pip install --user git+https://github.com/Maksim75ru/python-project-49.git`

### Game 1: Is That Even?

[![asciicast](https://asciinema.org/a/wmVqdtBxpsfMSPA5IcabkBLfT.svg)](https://asciinema.org/a/wmVqdtBxpsfMSPA5IcabkBLfT)